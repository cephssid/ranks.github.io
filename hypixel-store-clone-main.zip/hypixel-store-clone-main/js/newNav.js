let newNav = {
    data:[
        {
            id: 1,
            title: "Ranks",
            icon: ""
        },
        {
            id: 2,
            title: "Bundles",
            icon: ""
        }, 
        {
            id: 3,
            title: "Gold",
            icon: ""
        }, 
        {
            id: 4,
            title: "Boosters",
            icon: ""
        }, 
        {
            id: 5,
            title: "Mystery Boxes",
            icon: ""
        }, 
        {
            id: 6,
            title: "Companions",
            icon: ""
        }, 
        {
            id: 7,
            title: "Skyblock Gems",
            icon: ""
        }, 
        {
            id: 8,
            title: "Loot Chests",
            icon: ""
        }, 
        {
            id: 9,
            title: "Gifts",
            icon: ""
        },  
    ]
}